##
# Cluster management
##
import os
import sys
import json
import time
import yaml
import boto3
import logging
import os.path
import botocore

import pprint

pp = pprint.PrettyPrinter(width=41, compact=True)

from platops import util

from jinja2 import Template

def get_cluster( cluster ):
	cft_client = util.get_cft_client()

	try:
		stacks = cft_client.describe_stacks(
			StackName=cluster['name'])

		logging.debug(stacks)
		logging.debug("Found stack.")
		return stacks['Stacks'][0]

	except botocore.exceptions.ClientError:
		logging.debug("Stack does not exist.")
		return False


def get_cft_stack_name( cluster ):
	cft_client = util.get_cft_client()
	ro = cft_client.describe_stack_resources(
    	StackName=cluster['name'],
    	LogicalResourceId='ECSCluster'
	)
	return ro['StackResources'][0]['PhysicalResourceId']

def wait_for_cft_stack( stack_name ):
	cft_client = util.get_cft_client()
	stacks = cft_client.describe_stacks(StackName=stack_name)

	waiting = True
	start = time.time()

	while waiting == True:
		ro = cft_client.describe_stacks(StackName=stack_name)
		status = ro['Stacks'][0]['StackStatus']
		#pp.pprint(stacks)
		if status == "CREATE_COMPLETE":
			waiting = False
			runtime = time.time() - start
			logging.debug("Runtime: %.4f" % runtime)

		elif status == "CREATE_IN_PROGRESS":
			logging.info("Waing for stack to come up: %s" % status)
			time.sleep(20)

		else:
			logging.fatal("Unknown stack status: %s" % status)
			exit()


"""
Inititate the pattern that comprises a ECS stack and it's components.
"""
def create_cluster( cluster ):
	logging.info('Creating cluster: %s' % cluster['name'] )

	## Assume this is a development type cluster, unless
	##	otherwise specified.
	env_class_type = "dev"

	## Load environment master configuration.
	env_file = os.path.join(util.get_base_dir(), 'config', "%s.yml" % env_class_type)
	env_base_yaml = yaml.load(open(env_file))
	logging.debug(env_base_yaml)

	## Load the local overrides
	local_env_file = os.path.join('.', "%s.yml" % cluster['env_name'])
	local_yaml = yaml.load(open(local_env_file))
	logging.debug(local_yaml)

	env_cfg = util.data_merge(env_base_yaml, local_yaml)
	logging.debug("Merged: %s" % env_cfg)

	## Now we have the configuration for the cluster environment.
	##	Start building the data structure for the cluster.

	## Load ECS json template.
	ecs_tpl_file = os.path.join(util.get_base_dir(), 'templates', 'ecs.json')
	ecs_json = json.loads(open(ecs_tpl_file).read())
	#logging.debug(ecs_json)

	tags = { 'owner': 'bkroger@thoughtworks.com' }
	params = {}

	tags['version'] = cluster['version']

	## Get AMI
	ami = util.get_ami(env_cfg['ami'])
	params['ImageId'] = ami['ImageId']

	params['NotificationUrl'] = env_cfg['notification_url']

	## Get the main vpc.
	vpc = util.get_vpc(env_cfg['vpc'])
	params['VpcId'] = vpc['VpcId']

	## Create a list of subnets.
	subnets = util.get_private_subnets(env_cfg['private_subnets'])
	
	zones = []
	private_subnets = []
	for subnet in subnets:
		zones.append(subnet['AvailabilityZone'])
		private_subnets.append(subnet['SubnetId'])

	params['Zones'] = ",".join(zones)
	params['PrivateSubnets'] = ",".join(private_subnets)

	params['KeyName'] = env_cfg['key_name']

	params['MaxSize'] = str(env_cfg['asg']['max'])
	params['MinSize'] = str(env_cfg['asg']['min'])
	params['DesiredCapacity'] = str(env_cfg['asg']['desired'])

	logging.debug(params)

	cft_tags = []
	cft_params = []

	for k in params:
		cft_params.append({
			'ParameterKey': k,
			'ParameterValue': params[k]
		})
	
	for k in tags:
		cft_tags.append({
			'Key': k,
			'Value': tags[k]
			})

	logging.debug(cft_params)

	cft_client = util.get_cft_client()
	cft_client.create_stack(
		Tags=cft_tags,
		DisableRollback=True,
		Capabilities=['CAPABILITY_IAM'],
		StackName=cluster['name'],
		TemplateBody=json.dumps(ecs_json),
		Parameters=cft_params)



def create_application( application, cluster ):
	logging.debug("Creating application.")

	env_class_type = "dev"

	## Load environment master configuration.
	env_file = os.path.join(util.get_base_dir(), 'config', "%s.yml" % env_class_type)
	env_base_yaml = yaml.load(open(env_file))
	logging.debug(env_base_yaml)

	## Load the local overrides
	local_env_file = os.path.join('.', "%s.yml" % cluster['env_name'])
	local_yaml = yaml.load(open(local_env_file))
	logging.debug(local_yaml)

	env_cfg = util.data_merge(env_base_yaml, local_yaml)
	logging.debug("Merged: %s" % env_cfg)

	ecs_tpl_file = os.path.join(util.get_base_dir(), 'templates', 'application.json')
	ecs_json = json.loads(open(ecs_tpl_file).read())

	tags = { 'owner': 'bkroger@thoughtworks.com' }
	params = { 'VpcId': 'vpc-815437e5' }

	subnets = util.get_private_subnets(env_cfg['public_subnets'])

	zones = []
	public_subnets = []
	for subnet in subnets:
		zones.append(subnet['AvailabilityZone'])
		public_subnets.append(subnet['SubnetId'])

	params['PublicSubnets'] = ",".join(public_subnets)

	#params['Zones'] = ",".join(zones)
	cluster_name = get_cft_stack_name(cluster)
	params['ClusterName'] = cluster_name
	params['ApplicationName'] = application['name']
	params['ApplicationImageUrl'] = application['image_url']
	params['HealthCheckPath'] = application['service']['health_check']['path']

	cft_tags = []
	cft_params = []

	for k in params:
		cft_params.append({
			'ParameterKey': k,
			'ParameterValue': params[k]
		})
	
	for k in tags:
		cft_tags.append({
			'Key': k,
			'Value': tags[k]
			})

	stack_name = "%s-%s" % (cluster['name'], application['name'])

	cft_client = util.get_cft_client()
	cft_client.create_stack(
		Tags=cft_tags,
		DisableRollback=True,
		Capabilities=['CAPABILITY_IAM'],
		StackName=stack_name,
		TemplateBody=json.dumps(ecs_json),
		Parameters=cft_params)

def application_exists( application, cluster ):
	## Look for a stack.
	stack_name = "%s-%s" % (cluster['name'], application['name'])

	cft_client = util.get_cft_client()

	try:
		logging.debug("Checking for stack: %s" % stack_name)
		ro = cft_client.describe_stacks(StackName=stack_name)
		pp.pprint(ro)
		return True

	except botocore.exceptions.ClientError:
		logging.debug("Stack does not exist.")
		return False

def deploy_new_version( application, cluster ):
	if application_exists( application, cluster ) == False:
		create_application( application, cluster )

	else:
		logging.debug("Deploying new application.")

	stack_name = "%s-%s" % (cluster['name'], application['name'])
	wait_for_cft_stack( stack_name )

	family_name = get_cft_task_name(stack_name)
	logging.debug("FamilyName: %s" % family_name)

	current_task_def = get_task_def(family_name)

	cluster_name = get_cft_stack_name(cluster)
	service_name = get_cft_service_name(stack_name)

	logging.info("ServiceName: %s" % service_name)

	task = current_task_def['taskDefinition']['containerDefinitions'][0]
	current_image = task['image']
	
	task['image'] = application['image_url']

	new_task = register_new_task(current_task_def['taskDefinition']['family'], task)

	cft_client = util.get_cft_client()

	logging.debug("Updating service.")
	response = util.get_ecs_client().update_service(
    	cluster=cluster_name,
    	service=service_name,
    	taskDefinition=new_task['taskDefinition']['taskDefinitionArn']
	)
	logging.info("Service update complete.")

def register_new_task( family_name, task ):
	logging.debug("Registering new task definition.")
	reg_task_def = util.get_ecs_client().register_task_definition(
		family=family_name,
    	networkMode='bridge',
    	containerDefinitions=[task]
    	#volumes=task['taskDefinition']['volumes']
	)
	logging.info("New task registration complete.")
	return reg_task_def

def get_cft_task_name( stack_name ):
	cft_client = util.get_cft_client()
	ro = cft_client.describe_stack_resources(
    	StackName=stack_name,
    	LogicalResourceId='Task'
	)
	return ro['StackResources'][0]['PhysicalResourceId']

def get_cft_service_name( stack_name ):
	cft_client = util.get_cft_client()
	ro = cft_client.describe_stack_resources(
    	StackName=stack_name,
    	LogicalResourceId='Service'
	)
	return ro['StackResources'][0]['PhysicalResourceId']

def get_task_def(family_name):
	logging.info("Getting current task def.")
	try:
		response = util.get_ecs_client().describe_task_definition(
			taskDefinition=family_name
		)
		logging.debug("Found task def.")
		return response

	except botocore.exceptions.ClientError:
		logging.debug("Unable to find task def.")
		return False




