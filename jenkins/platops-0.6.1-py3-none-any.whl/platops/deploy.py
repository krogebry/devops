##
# Deploy helper
##
import os
import sys
import json
import yaml
import boto3
import logging
import os.path

from platops import util
from platops import cluster_manager as cm

def deploy( args ):
	env_name = args.env_name
	service_name = args.service
	new_version = args.image_version
	env_version = args.env_version

	if env_version is None:
		env_version = "0-1-0"

	cluster = {
		'name': "%s-%s" % (env_name, env_version),
		'version': env_version,
		'env_name': env_name
	}
	
	cft = cm.get_cluster( cluster )
	if cft == False:
		cm.create_cluster( cluster )
	
	cm.wait_for_cft_stack( cluster['name'] )

	logging.debug(cft)

	if cft != False and cft['StackStatus'] == 'CREATE_IN_PROGRESS':
		cm.wait_for_cft_stack( cluster['name'] )

	elif cft['StackStatus'] == 'CREATE_COMPLETE':
		logging.debug('Stack creation complete.')

	else:
		logging.fatal("Unknown stack status")
		exit()

	local_app_file = os.path.join('.', "%s.yml" % service_name)
	application = yaml.load(open(local_app_file))
	logging.debug(application)

	if new_version != None:
		version_tag = new_version
	else:
		version_tag = "latest"

	image_name = application['docker']['image_name']

	application['image_url'] = "168860074409.dkr.ecr.us-west-2.amazonaws.com/%s:%s" % (image_name, version_tag)

	application['family_name'] = "%s-%s" % (env_name, application['name'])
	application['service_name'] = "%s-%s" % (env_name, application['name'])

	cm.deploy_new_version( application, cluster )



