##
# Utilities
##
import os
import sys
import six
import json
import yaml
import boto3
import logging
import os.path

import subprocess

from jinja2 import Template

# [bkroger@thoughtworks.com] borrowed from:
#	https://github.com/ImmobilienScout24/yamlreader/blob/master/src/main/python/yamlreader/yamlreader.py
def data_merge(a, b):
    """merges b into a and return merged result
    based on http://stackoverflow.com/questions/7204805/python-dictionaries-of-dictionaries-merge
    and extended to also merge arrays and to replace the content of keys with the same name
    NOTE: tuples and arbitrary objects are not handled as it is totally ambiguous what should happen"""
    key = None
    try:
        if a is None or isinstance(a, (six.string_types, float, six.integer_types)):
            # border case for first run or if a is a primitive
            a = b
        elif isinstance(a, list):
            # lists can be only appended
            if isinstance(b, list):
                # merge lists
                a.extend(b)
            else:
                # append to list
                a.append(b)
        elif isinstance(a, dict):
            # dicts must be merged
            if isinstance(b, dict):
                for key in b:
                    if key in a:
                        a[key] = data_merge(a[key], b[key])
                    else:
                        a[key] = b[key]
            else:
                raise YamlReaderError('Cannot merge non-dict "%s" into dict "%s"' % (b, a))
        else:
            raise YamlReaderError('NOT IMPLEMENTED "%s" into "%s"' % (b, a))
    except TypeError as e:
        raise YamlReaderError('TypeError "%s" in key "%s" when merging "%s" into "%s"' % (e, key, b, a))
    return a

def get_ecs_client():
	return boto3.client('ecs')

def get_cft_client():
	return boto3.client('cloudformation')

def get_base_dir():
	return os.path.dirname(__file__)

def get_ec2_client():
	return boto3.client('ec2')

def get_ami( cfg ):
	ec2_client = get_ec2_client()

	#print(cfg)

	filters = [{
		'Name': "tag:Name",
		'Values': [cfg['Name']]
	},{
		'Name': "tag:Version",
		'Values': [cfg['Version']]
	}]

	ro = ec2_client.describe_images(Filters=filters)

	#pp.pprint(ro)

	return ro['Images'][0]

def get_vpc( vpc ):
	ec2_client = get_ec2_client()

	filters = {
		'Name': "tag:Name",
		'Values': [vpc['Name']]
	}
	ro = ec2_client.describe_vpcs(Filters=[filters])

	return ro['Vpcs'][0]

def get_private_subnets( subs ):
	logging.debug("Getting subnets: %s" % subs)

	ec2_client = get_ec2_client()

	filters = {
		'Name': "tag:Name",
		'Values': []
	}

	for sub in subs:
		filters['Values'].append(sub['Name'])

	logging.debug(filters)

	ro = ec2_client.describe_subnets(Filters=[filters])

	return ro['Subnets']
