##
# Deploy helper
##
import os
import sys
import json
import yaml
import boto3
import logging
import os.path

import consul

c = consul.Consul()

def populate_services():
	#services = ['pdp', 'browse']
	service_name = "browse"
	#c.kv.put("services/%s" % service_name, "config")
	c.kv.put("services/%s/config/num_cpus" % service_name, "3")

	c.agent.service.register(name=service_name, tags=['nmo'])

def get_config():
	#services = c.kv.get('services/', recurse=True)
	#logging.debug(services[1])

	services = c.agent.services()
	#logging.debug(services)
	
	for name in services:
		info = services[name]
		if "nmo" not in info["Tags"]:
			continue

		logging.debug("Service: %s" % name)
		index, num_cpus = c.kv.get("services/%s/config/num_cpus" % name)

		#logging.debug(num_cpus)
		#if index is not 'NoneType':
			#logging.debug("Num CPUs: %s" % num_cpus['Value'])

def apply(args):
	#populate_services()
	#get_config()

	version = args.version
	env_name = args.env_name

	cluster_name = "%s-%s" % (env_name, version)

	## Check to see if the current stack exists.
	logging.debug("Checking for cluster.")
	clusters = ecs_client.describe_clusters(
		'clusters'=[cluster_name]
	)
	print(clusters)
	#logging.info("New task registration complete.")


