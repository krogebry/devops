##
# Cleaner.
##
import os
import sys
import json
import time
import yaml
import boto3
import logging
import os.path
import botocore

import pprint
import hashlib

pp = pprint.PrettyPrinter(width=41, compact=True)

from platops import util

def cleanup(args):
	clean_task_defs(args)

def put_cache( key, data ):
	cache_dir = os.path.join('/', 'tmp', 'cache')
	if os.path.isdir(cache_dir) == False:
		os.mkdir(cache_dir)
	
	cache_file = os.path.join(cache_dir, key)

	f = open(cache_file, 'w')
	f.write(data)
	f.close()

def get_cache( key ):
	cache_dir = os.path.join('/', 'tmp', 'cache')
	if os.path.isdir(cache_dir) == False:
		os.mkdir(cache_dir)
	cache_file = os.path.join(cache_dir, key)

	if os.path.isfile(cache_file) == False:
		return False
	
	else:
		return open(cache_file).read()

def get_service_tasks( cluster_arn, services, force=False ):
	ecs_client = util.get_ecs_client()
	cache_key = "services_%s_services" % hashlib.md5(cluster_arn.encode('utf-8')).hexdigest()
	cache = get_cache( cache_key )
	if cache == False or force == True:
		logging.debug("Getting from source.")
		data = ecs_client.describe_services(
			cluster=cluster_arn,
			services=services)['services']
		#pp.pprint( data )
		ro = []
		for d in data:
			#d.pop('events')
			#pp.pprint(d)
			ro.append(d['taskDefinition'])

		#pp.pprint(ro)
		put_cache( cache_key, json.dumps(ro) )

	else:
		ro = json.loads( cache )

	return ro

def get_task_definitions( force=False ):
	ecs_client = util.get_ecs_client()
	cache_key = "task_definitions"
	cache = get_cache( cache_key )
	if cache == False or force == True:
		logging.debug("Getting from source.")
		data = ecs_client.list_task_definitions()['taskDefinitionArns']
		put_cache( cache_key, json.dumps(data) )
	
	else:
		data = json.loads( cache )
	
	return data

def get_service_arns( cluster_arn, force=False ):
	ecs_client = util.get_ecs_client()
	cache_key = "services_%s" % hashlib.md5(cluster_arn.encode('utf-8')).hexdigest()
	cache = get_cache( cache_key )
	if cache == False or force == True:
		logging.debug("Getting from source.")
		data = ecs_client.list_services(
			cluster=cluster_arn
		)['serviceArns']
		#pp.pprint( data )
		put_cache( cache_key, json.dumps(data) )
	
	else:
		data = json.loads( cache )
	
	return data

def get_clusters( force=False ):
	ecs_client = util.get_ecs_client()
	cache_key = "clusters"
	cache = get_cache( cache_key )
	if cache == False or force == True:
		logging.debug("Getting from source.")
		cluster_arns = ecs_client.list_clusters()['clusterArns']
		#pp.pprint( cluster_arns )
		put_cache( cache_key, json.dumps(cluster_arns) )
		
	else:
		cluster_arns = json.loads( cache )
	
	return cluster_arns

def clean_task_defs(args):
	logging.info("Cleaning old task definitions.")

	ecs_client = util.get_ecs_client()

	running_task_defs = []

	cluster_arns = get_clusters( args.force )

	for cluster_arn in cluster_arns:
		service_arns = get_service_arns( cluster_arn )
		## get service descriptions for each service arn
		if len(service_arns) == 0:
			continue
		
		service_descriptions = get_service_tasks( cluster_arn, service_arns, args.force )

		for s in service_descriptions:
			running_task_defs.append(s)

	all_task_defs = get_task_definitions( args.force )

	target_list = list(set(all_task_defs) - set(running_task_defs))

	for task_def in target_list:
		logging.info("Deregistering task: %s" % task_def)
		response = ecs_client.deregister_task_definition(taskDefinition=task_def)
		pp.pprint(response)





