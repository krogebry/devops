import os
import sys
import json
import yaml
import argparse
import logging
import os.path
import pkg_resources

from platops import deploy
from platops import util
from platops import cleaner

version_file = os.path.join(os.path.dirname(__file__), 'VERSION')
if os.path.exists(version_file):
    version = open(version_file).read().strip()
    basedir = os.path.join(os.path.dirname(__file__), "../")
else:
    dist = pkg_resources.get_distribution('platops')
    version = dist.version
    basedir = os.path.dirname(__file__)

def print_version():
    print("Version: %s" % version)

def main(args=None):
    if args is None:
        args = sys.argv[1:]
    
    parser = argparse.ArgumentParser(description="Platform Tool")

    parser.add_argument('-v', '--verbose', action='store_true', help='Enable verbosity', default=False)
    parser.add_argument('-d', '--dry-run', action='store_true', help='Perform a dry run', default=False)

    subparsers = parser.add_subparsers(metavar="<command>")

    version_parser = subparsers.add_parser('version', help='Version information')

    deploy_parser = subparsers.add_parser('deploy', help='Apply changes to ECS')
    deploy_parser.add_argument('-e', '--env_version', metavar='env_version', help='Override the env version.')
    deploy_parser.add_argument('env_name', metavar='env_name', help='Environment name ( dev )')
    deploy_parser.add_argument('service', metavar='service', help='Service name ( browse )')
    deploy_parser.add_argument('-i', '--image_version', metavar='image_version', help='Override the image tag with this value.')
    deploy_parser.set_defaults(func=deploy.deploy)

    cleaner_parser = subparsers.add_parser('cleaner', help='Cleanup')
    cleaner_parser.add_argument('-f', '--force', action='store_true', help='Force cache overdie')
    cleaner_parser.set_defaults(func=cleaner.cleanup)

    args = parser.parse_args()

    logging.getLogger('botocore').setLevel(logging.WARNING)

    if hasattr(args, 'func') is False:
        print_version()
    else:
        if args.verbose is True:
            logging.basicConfig(level=logging.DEBUG)
        else:
            logging.basicConfig(level=logging.INFO)

        logging.debug(args)
        args.func(args)

if __name__ == "__main__":
    main()